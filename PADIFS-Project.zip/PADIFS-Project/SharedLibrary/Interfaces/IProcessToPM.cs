﻿
namespace SharedLibrary.Interfaces
{
    public interface IProcessToPM
    {
        void Dump(); 
        void MetadataLocation(string id, string location);
    }
}
